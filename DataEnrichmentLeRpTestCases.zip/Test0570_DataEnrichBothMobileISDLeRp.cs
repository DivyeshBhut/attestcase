using NUnit.Framework;
using TrackWizzSaaS.Ckyc.Test.CkycSubmissionDashboard.RecordDetails.Operation.Helpers;
using TrackWizzSaaS.Core.Test;

namespace TrackWizzSaaS.Ckyc.Test.Operation.DataEnrichment.TestCases
{
    [TestFixture]
    [Parallelizable(ParallelScope.All)]
    public class Test0570_DataEnrichBothMobileISDLeRp : BaseTest
    {
        private static IEnumerable<TestCaseData> DataEnrichBothMobileISDLeRp()
        {
            yield return new TestCaseData(
                "LE_SOURCE_SYSTEM_CUSTOMER_CODE", // TODO: replace with actual LE Source System Customer Code
                new List<OperationProperties>
                {
                    new OperationProperties
                    {
                        Operation_Name = OperationConstant.DataEnrichmentOperation,
                        Status = OperationConstant.Completed,
                        Outcome = OperationConstant.Success
                    }
                });
        }

        [Test]
        [Description("")]
        [Category("Operations")]
        [Property("Feature", "Data Enrichment")]
        [Property("Component", "CKYC Submission")]
        [TestCaseSource(nameof(DataEnrichBothMobileISDLeRp))]
        public async Task AT6147_DataEnrichBothMobileISDLeRp(string leSourceSystemCustomerCode, List<OperationProperties> dataEnrichmentOperationDetailsExpected)
        {
            var dataEnrichmentLeRpCommon = new DataEnrichmentLeRpCommon(page, TestDataPath);
            await dataEnrichmentLeRpCommon.DataEnrichmentLeRpValidation(GetMethodName(), leSourceSystemCustomerCode, dataEnrichmentOperationDetailsExpected);
        }
    }
}
