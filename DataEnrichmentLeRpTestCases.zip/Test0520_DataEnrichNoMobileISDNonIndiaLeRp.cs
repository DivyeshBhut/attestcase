using NUnit.Framework;
using TrackWizzSaaS.Ckyc.Test.CkycSubmissionDashboard.RecordDetails.Operation.Helpers;
using TrackWizzSaaS.Core.Test;

namespace TrackWizzSaaS.Ckyc.Test.Operation.DataEnrichment.TestCases
{
    [TestFixture]
    [Parallelizable(ParallelScope.All)]
    public class Test0520_DataEnrichNoMobileISDNonIndiaLeRp : BaseTest
    {
        private static IEnumerable<TestCaseData> DataEnrichNoMobileISDNonIndiaLeRp()
        {
            yield return new TestCaseData(
                "LE_SOURCE_SYSTEM_CUSTOMER_CODE", // TODO: replace with actual LE Source System Customer Code
                new List<OperationProperties>
                {
                    new OperationProperties
                    {
                        Operation_Name = OperationConstant.DataEnrichmentOperation,
                        Status = OperationConstant.Completed,
                        Outcome = OperationConstant.Success
                    }
                });
        }

        [Test]
        [Description("")]
        [Category("Operations")]
        [Property("Feature", "Data Enrichment")]
        [Property("Component", "CKYC Submission")]
        [TestCaseSource(nameof(DataEnrichNoMobileISDNonIndiaLeRp))]
        public async Task AT6142_DataEnrichNoMobileISDNonIndiaLeRp(string leSourceSystemCustomerCode, List<OperationProperties> dataEnrichmentOperationDetailsExpected)
        {
            var dataEnrichmentLeRpCommon = new DataEnrichmentLeRpCommon(page, TestDataPath);
            await dataEnrichmentLeRpCommon.DataEnrichmentLeRpValidation(GetMethodName(), leSourceSystemCustomerCode, dataEnrichmentOperationDetailsExpected);
        }
    }
}
