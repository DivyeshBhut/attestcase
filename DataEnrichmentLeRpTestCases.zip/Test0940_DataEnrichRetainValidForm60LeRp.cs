using NUnit.Framework;
using TrackWizzSaaS.Ckyc.Test.CkycSubmissionDashboard.RecordDetails.Operation.Helpers;
using TrackWizzSaaS.Core.Test;

namespace TrackWizzSaaS.Ckyc.Test.Operation.DataEnrichment.TestCases
{
    [TestFixture]
    [Parallelizable(ParallelScope.All)]
    public class Test0940_DataEnrichRetainValidForm60LeRp : BaseTest
    {
        private static IEnumerable<TestCaseData> DataEnrichRetainValidForm60LeRp()
        {
            yield return new TestCaseData(
                "LE_SOURCE_SYSTEM_CUSTOMER_CODE", // TODO: replace with actual LE Source System Customer Code
                new List<OperationProperties>
                {
                    new OperationProperties
                    {
                        Operation_Name = OperationConstant.DataEnrichmentOperation,
                        Status = OperationConstant.Completed,
                        Outcome = OperationConstant.Success
                    }
                });
        }

        [Test]
        [Description("")]
        [Category("Operations")]
        [Property("Feature", "Data Enrichment")]
        [Property("Component", "CKYC Submission")]
        [TestCaseSource(nameof(DataEnrichRetainValidForm60LeRp))]
        public async Task AT6184_DataEnrichRetainValidForm60LeRp(string leSourceSystemCustomerCode, List<OperationProperties> dataEnrichmentOperationDetailsExpected)
        {
            var dataEnrichmentLeRpCommon = new DataEnrichmentLeRpCommon(page, TestDataPath);
            await dataEnrichmentLeRpCommon.DataEnrichmentLeRpValidation(GetMethodName(), leSourceSystemCustomerCode, dataEnrichmentOperationDetailsExpected);
        }
    }
}
