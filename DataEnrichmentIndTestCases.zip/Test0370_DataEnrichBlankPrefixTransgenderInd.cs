using NUnit.Framework;
using TrackWizzSaaS.Ckyc.Test.CkycSubmissionDashboard.RecordDetails.Operation.Helpers;
using TrackWizzSaaS.Core.Test;

namespace TrackWizzSaaS.Ckyc.Test.Operation.DataEnrichment.TestCases
{
    [TestFixture]
    [Parallelizable(ParallelScope.All)]
    public class Test0370_DataEnrichBlankPrefixTransgenderInd : BaseTest
    {
        private static IEnumerable<List<OperationProperties>> DataEnrichBlankPrefixTransgenderInd()
        {
            yield return new()
            {
                new OperationProperties
                {
                    Operation_Name = OperationConstant.DataEnrichmentOperation,
                    Status = OperationConstant.Completed,
                    Outcome = OperationConstant.Success
                }
            };
        }

        [Test]
        [Description("")]
        [Category("Operations")]
        [Property("Feature", "Data Enrichment")]
        [Property("Component", "CKYC Submission")]
        [TestCaseSource(nameof(DataEnrichBlankPrefixTransgenderInd))]
        public async Task AT6127_DataEnrichBlankPrefixTransgenderInd(List<OperationProperties> dataEnrichmentOperationDetailsExpected)
        {
            var dataEnrichmentIndCommon = new DataEnrichmentIndCommon(page, TestDataPath);
            await dataEnrichmentIndCommon.DataEnrichmentIndValidation(GetMethodName(), dataEnrichmentOperationDetailsExpected);
        }
    }
}
