using NUnit.Framework;
using TrackWizzSaaS.Ckyc.Test.CkycSubmissionDashboard.RecordDetails.Operation.Helpers;
using TrackWizzSaaS.Core.Test;

namespace TrackWizzSaaS.Ckyc.Test.Operation.DataEnrichment.TestCases
{
    [TestFixture]
    [Parallelizable(ParallelScope.All)]
    public class Test0480_DataEnrichRetainForm60YesInd : BaseTest
    {
        private static IEnumerable<List<OperationProperties>> DataEnrichRetainForm60YesInd()
        {
            yield return new()
            {
                new OperationProperties
                {
                    Operation_Name = OperationConstant.DataEnrichmentOperation,
                    Status = OperationConstant.Completed,
                    Outcome = OperationConstant.Success
                }
            };
        }

        [Test]
        [Description("")]
        [Category("Operations")]
        [Property("Feature", "Data Enrichment")]
        [Property("Component", "CKYC Submission")]
        [TestCaseSource(nameof(DataEnrichRetainForm60YesInd))]
        public async Task AT6138_DataEnrichRetainForm60YesInd(List<OperationProperties> dataEnrichmentOperationDetailsExpected)
        {
            var dataEnrichmentIndCommon = new DataEnrichmentIndCommon(page, TestDataPath);
            await dataEnrichmentIndCommon.DataEnrichmentIndValidation(GetMethodName(), dataEnrichmentOperationDetailsExpected);
        }
    }
}
