using NUnit.Framework;
using TrackWizzSaaS.Ckyc.Test.CkycSubmissionDashboard.RecordDetails.Operation.Helpers;
using TrackWizzSaaS.Core.Test;

namespace TrackWizzSaaS.Ckyc.Test.Operation.DataEnrichment.TestCases
{
    [TestFixture]
    [Parallelizable(ParallelScope.All)]
    public class Test0210_DataEnrichTrimZipLookupInd : BaseTest
    {
        private static IEnumerable<List<OperationProperties>> DataEnrichTrimZipLookupInd()
        {
            yield return new()
            {
                new OperationProperties
                {
                    Operation_Name = OperationConstant.DataEnrichmentOperation,
                    Status = OperationConstant.Completed,
                    Outcome = OperationConstant.Success
                }
            };
        }

        [Test]
        [Description("")]
        [Category("Operations")]
        [Property("Feature", "Data Enrichment")]
        [Property("Component", "CKYC Submission")]
        [TestCaseSource(nameof(DataEnrichTrimZipLookupInd))]
        public async Task AT6111_DataEnrichTrimZipLookupInd(List<OperationProperties> dataEnrichmentOperationDetailsExpected)
        {
            var dataEnrichmentIndCommon = new DataEnrichmentIndCommon(page, TestDataPath);
            await dataEnrichmentIndCommon.DataEnrichmentIndValidation(GetMethodName(), dataEnrichmentOperationDetailsExpected);
        }
    }
}
